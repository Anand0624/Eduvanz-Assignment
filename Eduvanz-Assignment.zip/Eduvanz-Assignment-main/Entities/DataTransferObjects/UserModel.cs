﻿using Entities.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Entities.DataTransferObjects
{
    public class UserModel
    {
        public Int64 Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(10, ErrorMessage = "Name can't be longer than 10 characters")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Age is required")]
        public Int64 Age { get; set; }

        [Required(ErrorMessage = "Date of birth is required")]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Profession is required")]
        [StringLength(10, ErrorMessage = "Profession can't be longer than 10 characters")]
        public string Profession { get; set; }

        [Required(ErrorMessage = "Locality is required")]
        [StringLength(20, ErrorMessage = "Locality can't be longer than 20 characters")]
        public string Locality { get; set; }

        [Required(ErrorMessage = "No of guest is required")]
        [StringLength(2, ErrorMessage = "guest can't be more than 2")]
        public Int64 NoOfGuest { get; set; }

        [Required(ErrorMessage = "Address is required")]
        [StringLength(100, ErrorMessage = "Address cannot be loner then 50 characters")]
        public string Address { get; set; }

        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }

    }
}
